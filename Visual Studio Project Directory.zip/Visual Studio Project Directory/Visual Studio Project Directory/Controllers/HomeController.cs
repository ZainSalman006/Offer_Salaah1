﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Visual_Studio_Project_Directory.Models;
namespace Visual_Studio_Project_Directory.Controllers
{ 
    public class HomeController : Controller
    {
        DataClasses1DataContext dc = new DataClasses1DataContext();
        public ActionResult Index()
        {
            var selection = dc.Masjids_Infos.Select(b => b.city).Distinct();
            ViewBag.city = selection;

            var selection1 = dc.Masjids_Infos.Select(b => b.area).Distinct();
            ViewBag.area = selection1;

            return View();
        }

        public ActionResult temp()
        {
            

            string city = Request["city"];
            string area = Request["area"];
            if (city != "" && area != "all")
            {
               var model = dc.Masjids_Infos.Where(a => a.city == city && a.area == area).ToList();
                ViewBag.data = model;
            }
            else
            {
                var model = dc.Masjids_Infos.Where(a => a.city == city).ToList();
                ViewBag.data = model;
            }

            //ViewBag.data = model;

            return View();
        }

        public ActionResult AddMasjid()
        {
            ViewBag.Message = "Please Fill the Following Form and Click on the Add" +
                " Button to Add your Masjid on our Site";

            return View();
        }

        public ActionResult EditMasjidDetails()
        {
            ViewBag.Message = "Please Fill the Following Form and Click on the Edit" +
                " Button to Edit your Masjid Details";
            return View();
        }

        [HttpPost]
        public ActionResult AddMasjidEntry()
        {
            Masjids_Info masjid = new Masjids_Info();

            masjid.name = Request["name"].ToString();
            masjid.area = Request["area"];
            masjid.city = Request["city"];
            masjid.jummahtime = TimeSpan.Parse(Request["jummahtime"]);
            masjid.fajartime = TimeSpan.Parse(Request["fajartime"]);
            masjid.zuhrtime = TimeSpan.Parse(Request["zuhrtime"]);
            masjid.asartime = TimeSpan.Parse(Request["asartime"]);
            masjid.magribtime = TimeSpan.Parse(Request["magribtime"]);
            masjid.eshatime = TimeSpan.Parse(Request["eshatime"]);
            masjid.address = Request["address"];
            masjid.Country = Request["Country"];

            dc.Masjids_Infos.InsertOnSubmit(masjid);
            dc.SubmitChanges();

            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult UpdateMasjidDetails()
        {
            
            //Masjids_Info masjid = new Masjids_Info();

            int id = Convert.ToInt32((Request["id"]));
            //masjid.name = Request["name"].ToString();
            //masjid.area = Request["area"];
            //masjid.city = Request["city"];
            //masjid.jummahtime = TimeSpan.Parse(Request["jummahtime"]);
            //masjid.fajartime = TimeSpan.Parse(Request["fajartime"]);
            //masjid.zuhrtime = TimeSpan.Parse(Request["zuhrtime"]);
            //masjid.asartime = TimeSpan.Parse(Request["asartime"]);
            //masjid.magribtime = TimeSpan.Parse(Request["magribtime"]);
            //masjid.eshatime = TimeSpan.Parse(Request["eshatime"]);
            //masjid.address = Request["address"];
            //masjid.Country = Request["Country"];

            Masjids_Info  obj = dc.Masjids_Infos.First(d =>id==d.id);
            if (Request["name"] == "")
            {
                obj.name = obj.name;
            }
            else
            {
                obj.name = Request["name"];
            }

            if (Request["area"] == "")
            {
                obj.area = obj.area;
            }
            else
            {
                obj.area = Request["area"];
            }

            if (Request["city"] == "")
            {
                obj.city = obj.city;
            }
            else
            {
                obj.city = Request["city"];
            }

            if (Request["jummahtime"] == "")
            {
                obj.jummahtime = obj.jummahtime;
            }
            else
            {
                obj.jummahtime = TimeSpan.Parse(Request["jummahtime"]);
            }


            if (Request["fajartime"] == "")
            {
                obj.fajartime = obj.fajartime;
            }
            else
            {
                obj.fajartime = TimeSpan.Parse(Request["fajartime"]);
            }

            if (Request["zuhrtime"] == "")
            {
                obj.zuhrtime = obj.zuhrtime;
            }
            else
            {
                obj.zuhrtime = TimeSpan.Parse(Request["zuhrtime"]);
            }

            if (Request["asartime"] == "")
            {
                obj.asartime = obj.asartime;
            }
            else
            {
                obj.asartime = TimeSpan.Parse(Request["asartime"]);
            }

            if (Request["magribtime"] == "")
            {
                obj.magribtime = obj.magribtime;
            }
            else
            {
                obj.magribtime = TimeSpan.Parse(Request["magribtime"]);
            }

            if (Request["eshatime"] == "")
            {
                obj.eshatime = obj.eshatime;
            }
            else
            {
                obj.eshatime = TimeSpan.Parse(Request["eshatime"]);
            }

            if (Request["address"] == "")
            {
                obj.address = obj.address;
            }
            else
            {
                obj.address = Request["address"];
            }

            if (Request["Country"] == "")
            {
                obj.Country = obj.Country;
            }
            else
            {
                obj.Country = Request["Country"];
            }


            dc.SubmitChanges();


            return RedirectToAction("AddMasjid");
        }

        [HttpPost]
        public ActionResult ShowMasjidDetails()
        {
            
            return RedirectToAction("temp");
        }
    }
}